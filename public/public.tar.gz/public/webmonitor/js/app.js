var glancesApp = angular.module('glancesApp', ['ngRoute'])

.config(function($routeProvider, $locationProvider) {
    $routeProvider.when('/monitor/web', {
        templateUrl : '/webmonitor/html/stats.html',
        controller : 'statsController'
    }).when('/monitor/web/:refresh_time', {
        templateUrl : '/webmonitor/html/stats.html',
        controller : 'statsController'
    });

    $locationProvider.html5Mode(true);
});
